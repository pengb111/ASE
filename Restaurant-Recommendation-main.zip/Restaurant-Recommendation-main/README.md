# Restaurant-Recommendation

This is the github repo for Group Jackdaw in Adaptive Applications. 

## Frontend

### Prerequisites

Angular Version is 13.

Node version required is 12.22.7 (atleast greater than 12). Use nvm to install https://tecadmin.net/install-nodejs-with-nvm/

Corresponding **npm** should be more than 6.

### How to run

- make sure you are in *angular-frontend* directory
- Execute **npm i** (One time only to install node modules) on command line
- Execute **npm run** on command line


